// Image Slider
let slideIndex = 0;
const slides = document.querySelectorAll('.slider img');
const prev = document.querySelector('.prev');
const next = document.querySelector('.next');

function showSlide(n) {
    slides.forEach((slide, index) => {
        slide.style.display = index === n ? 'block' : 'none';
    });
}

function nextSlide() {
    slideIndex = (slideIndex + 1) % slides.length;
    showSlide(slideIndex);
}

function prevSlide() {
    slideIndex = (slideIndex - 1 + slides.length) % slides.length;
    showSlide(slideIndex);
}

next.addEventListener('click', nextSlide);
prev.addEventListener('click', prevSlide);

// Auto slide
setInterval(nextSlide, 5000);

// Modal Pop-up for Gallery
function openModal(img) {
    const modal = document.getElementById('modal');
    const modalImg = document.getElementById('modal-img');
    const captionText = document.getElementById('caption');

    modal.style.display = 'block';
    modalImg.src = img.src;
    captionText.innerHTML = img.alt;
}

function closeModal() {
    const modal = document.getElementById('modal');
    modal.style.display = 'none';
}

// Initialize Datepicker
document.addEventListener('DOMContentLoaded', function() {
    flatpickr('.datepicker', {
        minDate: 'today'
    });
});

// JavaScript for handling the booking modals
document.addEventListener('DOMContentLoaded', function() {
    const deluxeModal = document.getElementById('deluxe-modal');
    const executiveModal = document.getElementById('executive-modal');
    const suiteModal = document.getElementById('suite-modal');
    const closeBtns = document.querySelectorAll('.close-btn');

    const deluxeButton = document.querySelector('.book-now[data-room="Deluxe Room"]');
    const executiveButton = document.querySelector('.book-now[data-room="Executive Room"]');
    const suiteButton = document.querySelector('.book-now[data-room="Suite Room"]');

    deluxeButton.addEventListener('click', function(e) {
        e.preventDefault();
        deluxeModal.style.display = 'block';
    });

    executiveButton.addEventListener('click', function(e) {
        e.preventDefault();
        executiveModal.style.display = 'block';
    });

    suiteButton.addEventListener('click', function(e) {
        e.preventDefault();
        suiteModal.style.display = 'block';
    });

    // Close modals when clicking the close button
    closeBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            deluxeModal.style.display = 'none';
            executiveModal.style.display = 'none';
            suiteModal.style.display = 'none';
        });
    });

    // Close modals when clicking outside the modal content
    window.addEventListener('click', function(e) {
        if (e.target === deluxeModal) {
            deluxeModal.style.display = 'none';
        } else if (e.target === executiveModal) {
            executiveModal.style.display = 'none';
        } else if (e.target === suiteModal) {
            suiteModal.style.display = 'none';
        }
    });

    // Handle form submission for Deluxe Room
    document.getElementById('deluxe-booking-form').addEventListener('submit', function(e) {
        e.preventDefault();
        alert('Thank you for booking the Deluxe Room! We will contact you shortly.');
        deluxeModal.style.display = 'none';
    });

    // Handle form submission for Executive Room
    document.getElementById('executive-booking-form').addEventListener('submit', function(e) {
        e.preventDefault();
        alert('Thank you for booking the Executive Room! We will contact you shortly.');
        executiveModal.style.display = 'none';
    });

    // Handle form submission for Suite Room
    document.getElementById('suite-booking-form').addEventListener('submit', function(e) {
        e.preventDefault();
        alert('Thank you for booking the Suite Room! We will contact you shortly.');
        suiteModal.style.display = 'none';
    });
});
